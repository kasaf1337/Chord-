import tkinter as tk
from tkinter import ttk
import openai
import threading
import subprocess
import sys

# Настройки API
api_key = "io-v2-eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJvd25lciI6ImYzNTM0Y2EyLWU5YzYtNGYxYS1hZjZlLTg1YjlmNjM0MjhlNiIsImV4cCI6NDg5Njg3MDY2MH0.HmC9SupfR_WRAGflQG-EVFQTQGZUQQiyKZIQD6D4A5fGMOvUNY28_MAw_p2XQmEnIjjpkDxndX4ct5vIILsiNg"  # Ваш ключ API
base_url = "https://api.intelligence.io.solutions/api/v1/"
client = openai.OpenAI(api_key=api_key, base_url=base_url)

# Поддерживаемые модели
models = [
    'Qwen/QwQ-32B',
    'meta-llama/Llama-3.3-70B-Instruct',
    'mistralai/Ministral-8B-Instruct-2410',
    'databricks/dbrx-instruct',
    'netease-youdao/Confucius-o1-14B',
    'microsoft/phi-4',
    'CohereForAI/c4ai-command-r-plus-08-2024',
    'THUDM/glm-4-9b-chat',
    'Qwen/Qwen2.5-1.5B-Instruct'
]

current_model_index = 0
max_words = 500000  # 500k слов на модель

# Функция отправки сообщения
def send_message():
    user_input = user_input_entry.get("1.0", tk.END).strip() # Исправлено здесь
    if not user_input:
        return
    append_message("Вы", user_input)
    user_input_entry.delete("1.0", tk.END) # Исправлено здесь
    loading_label.pack(pady=5)
    threading.Thread(target=get_ai_response, args=(user_input,)).start()

# Получение ответа от ИИ
def get_ai_response(user_input):
    global current_model_index
    try:
        response = client.chat.completions.create(
            model=models[current_model_index],
            messages=[
                {"role": "system", "content": "You are a helpful assistant."},
                {"role": "user", "content": user_input},
            ],
            temperature=0.7,
            stream=False,
            max_completion_tokens=1000,
        )
        ai_response = response.choices[0].message.content
        root.after(0, lambda: append_message("ИИ", ai_response))
        if len(chat_history.get("1.0", tk.END).split()) > max_words:
            current_model_index = (current_model_index + 1) % len(models)
            root.after(0, lambda: append_message("Система", f"Переключение на модель {models[current_model_index]}"))
    except Exception as e:
        root.after(0, lambda exception=e: append_message("Ошибка", str(exception)))
    loading_label.pack_forget()

# Добавление сообщения в историю чата
def append_message(sender, text):
    chat_history.config(state=tk.NORMAL)
    if sender == "Вы":
        chat_history.insert(tk.END, f"{sender}: {text}\n", "user")
    elif sender == "ИИ":
        chat_history.insert(tk.END, f"{sender}: {text}\n", "ai")
    elif sender == "Система":
        chat_history.insert(tk.END, f"{sender}: {text}\n", "system")
    else:
        chat_history.insert(tk.END, f"{sender}: {text}\n", "error")
    chat_history.config(state=tk.DISABLED)
    chat_history.see(tk.END)

# Функция для переключения моделей
def switch_model(index):
    global current_model_index
    current_model_index = index
    model_info_label.config(text=f"Текущая модель: {models[index]}")

# Создание окна
root = tk.Tk()
root.title("Kasafi AI Nexus")
root.geometry("600x600")
root.configure(bg="#282c34")

# Приветственное сообщение
welcome_label = tk.Label(root, text="Привет! Я сборка ИИ или просто Chord для помощи людям.\nby kasafi", bg="#282c34", fg="#c5c8c6", font=("Arial", 12))
welcome_label.pack(pady=10)

# Информация о текущей модели
model_info_label = tk.Label(root, text=f"Текущая модель: {models[current_model_index]}", bg="#282c34", fg="#c5c8c6", font=("Arial", 10), anchor=tk.NE)
model_info_label.pack(fill=tk.X, padx=10, anchor=tk.NE)

# Стили для тегов сообщений
chat_history = tk.Text(root, wrap=tk.WORD, bg="#3e4451", fg="#c5c8c6", bd=0, font=("Arial", 11))
chat_history.pack(padx=10, pady=10, fill=tk.BOTH, expand=True)
chat_history.config(state=tk.DISABLED)

chat_history.tag_config("user", foreground="#61afef", lmargin1=10, lmargin2=10)
chat_history.tag_config("ai", foreground="#c5c8c6", lmargin1=10, lmargin2=10)
chat_history.tag_config("system", foreground="#98c379", lmargin1=10, lmargin2=10)
chat_history.tag_config("error", foreground="#e06c75", lmargin1=10, lmargin2=10)

# Панель кнопок для выбора модели
model_button_frame = tk.Frame(root, bg="#282c34")
model_button_frame.pack(fill=tk.X, padx=10, pady=5)

model_label = tk.Label(model_button_frame, text="Выберите модель ИИ / Select AI model:", bg="#282c34", fg="#c5c8c6", font=("Arial", 10))
model_label.pack(side=tk.TOP, anchor=tk.W)

for i, model_name in enumerate(models):
    model_button = tk.Button(model_button_frame, text=f"{i + 1}", bg="#3e4451", fg="#61afef", bd=0, font=("Arial", 12), command=lambda index=i: switch_model(index))
    model_button.pack(side=tk.LEFT, padx=(0, 5))

# Нижняя панель ввода
input_frame = tk.Frame(root, bg="#282c34")
input_frame.pack(fill=tk.X, padx=10, pady=10)

# Окошко ввода
user_input_entry = tk.Text(input_frame, bg="#3e4451", fg="#c5c8c6", insertbackground="#c5c8c6", bd=0, font=("Arial", 11), height=3, relief=tk.FLAT)
user_input_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 10))

# Кнопка отправки
send_button = tk.Button(input_frame, text="➤", bg="#3e4451", fg="#61afef", bd=0, font=("Arial", 14), command=send_message)
send_button.pack(side=tk.RIGHT)

# Индикатор загрузки (крутящийся кружок)
loading_label = ttk.Progressbar(root, mode="indeterminate", length=100)
loading_label.pack_forget()
loading_label.start()

# Привязка Enter
user_input_entry.bind("<Return>", lambda event: send_message())

# Предупреждение о лимите слов
warning_label = tk.Label(root, text="Внимание! Лимит 500k слов на модель. Слова тратятся при использовании другими.", bg="#282c34", fg="#e06c75", font=("Arial", 10))
warning_label.pack(side=tk.BOTTOM, fill=tk.X, padx=10, pady=5)

# Автоматическая установка и обновление модулей
try:
    import openai
    import requests
except ImportError:
    subprocess.check_call([sys.executable, "-m", "pip", "install", "--upgrade", "pip", "openai", "requests"])

root.mainloop()
